<?php
namespace app\common\model;

use think\Model;

class OrderModel extends Model{
	
	protected $table = 'ly_order';
	
}