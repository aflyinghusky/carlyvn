<?php
namespace app\common\model;

use think\Model;

class TaskModel extends Model{
	//表名
	protected $table = 'ly_task';
}