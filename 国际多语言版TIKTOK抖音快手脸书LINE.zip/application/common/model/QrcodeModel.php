<?php

namespace app\common\model;

use think\Model;

class QrcodeModel extends Model{
	protected $table = 'ly_qrcode';
}