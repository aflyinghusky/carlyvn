<?php
namespace app\common\model;

use think\Model;

class UsersModel extends Model{
	
	protected $table = 'ly_users';

}