<?php
namespace app\manage\model;

use think\Model;

class SignModel extends Model{
	//表名
	protected $table = 'ly_sign';
}