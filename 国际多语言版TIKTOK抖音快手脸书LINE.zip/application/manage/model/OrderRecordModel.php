<?php
namespace app\manage\model;

use think\Model;

class OrderRecordModel extends Model{
	//表名
	protected $table = 'ly_order_record';
}