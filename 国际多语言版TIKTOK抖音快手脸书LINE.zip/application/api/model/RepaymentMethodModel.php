<?php

/**
 * 编写：祝踏岚
 * 用于获取系统设置数据
 */

namespace app\api\model;

use think\Model;

class RepaymentMethodModel extends Model{
	//表名
	protected $table = 'ly_repayment_method';
}