<?php

/**
 * 编写：祝踏岚
 * 作用：生成操作日志
 */

namespace app\admin\model;

use think\Model;

class SettingModel extends Model{
	//表名
	protected $table = 'ly_setting';
}